create function [dbo].[checkStatusVoucher](@voucherId varchar(10))
    returns bit
as
begin
    Declare @status bit;
    DECLARE @timeToUse bit;
    Declare @amountToUse bit;
    DECLARE @sumAmount int;
    DECLARE @usedAmount int;
    DECLARE @result bit;
    Set @status = 1;
    Set @timeToUse = 1;
    Set @amountToUse = 1;
    SET @result = '0';

    if (not exists(select *
                   from Voucher
                   where Id = @voucherId
                     and status = '1'))
        Set @status = 0;


    if (not exists(select *
                   from Voucher
                   where Id = @voucherId
                     and open_date < getdate()
                     and close_date > getdate()))
        Set @timeToUse = 0;


    SELECT @sumAmount =
           (case
                when amount is null then 0
                else
                    amount
               end
               )
    from Voucher
    where Id = @voucherId

    if (@sumAmount != 0)
        begin

            select @usedAmount = count(1)
            from [Order]
            where voucher_id = @voucherId
              and (status = '0' or status = '1' or status = '2' or status = '4');
            if (@sumAmount - @usedAmount <= 0)
                Set @amountToUse = 0;
        end


    if(@status = 1 and @timeToUse = 1 and @amountToUse = 1) SET @result = '1' ;
    return @result;
end
go

