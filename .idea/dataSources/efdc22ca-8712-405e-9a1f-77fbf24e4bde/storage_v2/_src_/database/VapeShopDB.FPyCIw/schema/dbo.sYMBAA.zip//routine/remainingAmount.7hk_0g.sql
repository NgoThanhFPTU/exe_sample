create function [dbo].[remainingAmount] (@product_type_id varchar(10))
    returns int
as
begin
    DECLARE @importamount int
    DECLARE @sellamount   int
    SET @importamount = 0
    SET @sellamount = 0

    select @importamount = (case
                                when sum(imp.quantity) is not null then sum(imp.quantity)
                                else 0
        end)

    from ImportProduct imp
    where imp.product_type_id = @product_type_id

    select @sellamount = (case
                              when sum(OrderDetail.amount) is not null then sum(OrderDetail.amount)
                              else 0
        end)
    from OrderDetail
             join [Order] O on O.order_id = OrderDetail.order_id
    where (O.status = '4' or  O.status = '2')
      and OrderDetail.product_type_id =@product_type_id;

    return @importamount - @sellamount

end
go

